﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefactorMe.Constants
{
    public struct CurrencyRate
    {
        public const double USDollar = 0.76;
        public const double Euro = 0.67;
        public const double Default = 1;
    }
}
