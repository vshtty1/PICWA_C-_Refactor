﻿using RefactorMe.DontRefactor.Data.Implementation;
using RefactorMe.DontRefactor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefactorMe.Utilities
{
    internal static class Helper
    {
        public static List<Product> GetAll(double currency)
        {
            var l = new LawnmowerRepository().GetAll().GetProductList("Lawnmower", currency);
            var p = new PhoneCaseRepository().GetAll().GetProductList("PhoneCase", currency);
            var t = new TShirtRepository().GetAll().GetProductList("TShirt", currency);

            return l.Concat(p).Concat(t).ToList();

        }
        public static List<Product> GetProductList(this IQueryable<Product> sourceList, string type, double currency)
        {
            var ps = new List<Product>();

            foreach (var i in sourceList)
            {
                ps.Add(new Product()
                {
                    Id = i.Id,
                    Name = i.Name,
                    Price = i.Price * currency,
                    Type = type
                });
            }
            return ps;
        }
        
    }
}
